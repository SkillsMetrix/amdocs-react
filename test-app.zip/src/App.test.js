


import { render,screen } from '@testing-library/react'
import App from './App'

test('should render the component on DOM',()=>{
    render(<App/>)
    const linkElement=screen.getByText(/This is React Testing/i)
    expect(linkElement).toBeInTheDocument()
})
test('render login component',()=>{
    const {getByLabelText}= render(<App/>)
    const childElement= getByLabelText("Email")
    expect(childElement).toBeTruthy()
})