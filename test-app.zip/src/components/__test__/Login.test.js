import {  render, screen,fireEvent } from "@testing-library/react";
import Login, { validateEmail } from "../Login";
import userEvent from '@testing-library/user-event'

describe("Test the Login Component", () => {
    test("render the login form submit button on the screen", async () => {
      render(<Login />);
      const buttonList = await screen.findAllByRole("button");
      expect(buttonList).toHaveLength(2);
    });
  
    test("should be failed on email validation ", () => {
      const testEmail = "dipesh.com";
      expect(validateEmail(testEmail)).not.toBe(true);
    });
  
    test("email input field should accept email ", () => {
      render(<Login />);
      const email = screen.getByPlaceholderText("Enter email");
      userEvent.type(email, "amar");
      expect(email.value).not.toMatch("amar@mail.com");
    });

    test("password type check ", () => {
        render(<Login />);
        const password = screen.getByPlaceholderText("Password");
         expect(password).toHaveAttribute("type","password")
      });
      test("should display alert if Error", async() => {
        render(<Login />);
        const email = screen.getByPlaceholderText("Enter email");
        const password = screen.getByPlaceholderText("Password");
        const buttonList = await screen.findAllByRole("button");
         userEvent.type(email, "amar");
        userEvent.type(password, "123456");
        userEvent.click(buttonList[0])
        const error= screen.getByText("Email is not valid")
        expect(error).toBeInTheDocument();
      });
  
      test("should reset", async() => {
       
        const {getByLabelText,getByTestId} = render(<Login />);
        const resetBtn= getByTestId('reset')
        const emailInput= getByLabelText("Email")
        const passInput= getByLabelText("Password")
        userEvent.click(resetBtn)
        expect(emailInput.value).toMatch("")
        expect(passInput.value).toMatch("")

      });
  
})

