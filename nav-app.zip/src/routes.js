import Login from "./components/Login";
import NotFound from "./components/NotFound";
import Portfolio from "./components/Portfolio";
import Register from "./components/Register";
import UserDetails from "./components/UserDetails";


export const routes=[
    {path:'/', element:<Login/>},
    {path:'/login', element:<Login/>},
    {path:'/register', element:<Register/>},
    {path:'/userdetails', element:<UserDetails/>},
    {path:'/portfolio/:uid', element:<Portfolio/>},
    {path:'*', element:<NotFound/>}
]