import React from 'react';

function NotFound(props) {
    return (
        <div>
            OOPS... Page not found
        </div>
    );
}

export default NotFound;