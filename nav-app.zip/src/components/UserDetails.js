import React, { useEffect } from 'react';
import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
 
function UserDetails(props) {
    const {uid} = useParams()
    const [user, setUser] = useState({})
    const navigate = useNavigate()
 
    useEffect(() => {
        const localUser = JSON.parse(localStorage.getItem('user'))
        if(localUser && localUser.uname === uid) {
            setUser(localUser)
        } else {
            navigate('/login')
        }
    },[])
 
    return (
        <div>
            User Details <br />
            Username : {user.uname} <br />
            Email : {user.email} <br />
        </div>
    );
}
 
export default UserDetails;