import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'

function Register() {
    const [users, setUsers] = useState([])
    const [errors, setErrors] = useState({})
    const navigate = useNavigate()

    const handleChange = (e) => {
        setUsers({ ...users, [e.target.name]: e.target.value })
    }
    const addUser = (e) => {

        e.preventDefault()
        const formError = validateForm(users)
        setErrors(formError)
        if (Object.keys(formError).length === 0) {
            localStorage.setItem('udata', JSON.stringify(users))
            navigate("/login")
        }

    }

    const validateForm = (data) => {
        const errors = {}
        if (!data.uname) {
            errors.uname = 'username is required'
        }
        return errors
    }


    return (

        <form onSubmit={addUser}>
            <input placeholder='Enter Username' type='text' name='uname' onChange={handleChange} />
            {errors.uname &&
                <span>{errors.uname}</span>
            }
            <input placeholder='Enter Password' type='password' name='password' onChange={handleChange} />
            <input placeholder='Enter Email' type='email' name='email' onChange={handleChange} />

            <button className='btn btn-success'>Register</button>
        </form>

    )

}
export default Register