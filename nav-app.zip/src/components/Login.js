import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
 
function Login() {
    const [users, setUsers] = useState([])
    const navigate= useNavigate()
 
    const handleChange=(e)=> {
        setUsers({...users, [e.target.name]: e.target.value})
    }
 
    const loginUser = (e) => {
        e.preventDefault()
        let details = JSON.parse(localStorage.getItem('udata'))
        if(details.uname == users.uname && details.password == users.password){
            navigate("/userdetails")
        }
    }
 
    return (
        <div>
            <form onSubmit={loginUser}>
                <input placeholder='Enter Username' type='text' name='uname' onChange={handleChange} />
                <input placeholder='Enter Password' type='password' name='password' onChange={handleChange} />
               
                <button className='btn btn-success'>Login</button>
            </form>
        </div>
    )
 
}
export default Login