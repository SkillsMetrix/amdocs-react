

import React from 'react';
import { Link } from 'react-router-dom'

function NavBar(props) {
    return (
        <div className='container'>
            <ul className='nav'>
                <li className='nav-item'>
                    <a className='nav-link' href='#'><Link to="/login">Login</Link></a>
                </li>
                <li className='nav-item'>
                    <a className='nav-link' href='#'><Link to="/register">Register</Link></a>
                </li>
                <li className='nav-item'>
                    <a className='nav-link' href='#'><Link to="/portfolio">Portfolio</Link></a>
                </li>
                <li className='nav-item'>
                    <a className='nav-link' href='#'><Link to="/Userdetails">UserDetails</Link></a>
                </li>
            </ul>

        </div>
    );
}

export default NavBar;