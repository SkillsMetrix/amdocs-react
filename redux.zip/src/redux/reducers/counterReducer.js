


const counterReducer=(state=100,action)=>{

    return state
}
export default counterReducer