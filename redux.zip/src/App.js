import logo from './logo.svg';
import './App.css';
import { useSelector } from 'react-redux'
function App() {
  const appCount= useSelector(state2 => state2.mycounter)
  return (
    <div className="App">
      <p>The count is : {appCount}</p>
    </div>
  );
}

export default App;
