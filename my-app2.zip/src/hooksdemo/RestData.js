import { Component } from "react";


export default class RestData extends Component{

    render(){
        return(
            <div>
                {this.props.rdata.map((udata) => (
                    <div>
                        {udata.name} -- {udata.email}
                    </div>
                ))}
            </div>
        )
    }
}