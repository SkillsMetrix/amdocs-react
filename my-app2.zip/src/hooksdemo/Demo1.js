
import { useEffect, useState } from 'react'

function Demo1() {
    //init the state


    //lifectylce 

    const [count, setCount] = useState(10)
    useEffect(() => {
        console.log('called during mount');
    }, [])
    useEffect(() => {
        console.log('called during update');
    }, [count])
    const inc = () => {
        setCount(count + 1)
    }
    return (
        <div>
            The Count is : {count}
            <button onClick={inc}>INC</button>
            <button onClick={() => setCount(count - 1)}>DEC</button>
        </div>
    )
}
export default Demo1