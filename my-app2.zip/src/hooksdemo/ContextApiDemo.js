
import { createContext, useContext, useState } from 'react'

//init the context
const appContext = createContext()
const userData = { id: 101, name: 'user-1', email: 'user@mail.com', income: 3456 }

function ContextApp() {
    const [emp, setEmp] = useState(userData)
    return (
        <div>
            <appContext.Provider value={emp}>
                <Employee />
            </appContext.Provider>
        </div>
    )
}

function Employee() {
    const empContext=useContext(appContext)
    return (
        <div>
            <p>UserName :{empContext.name}</p>
            <p>email :{empContext.email}</p>
            <hr/>
            <Salary />
        </div>
    )
}

function Salary() {
    const salaryContext=useContext(appContext)
    return (
        <div>
            Salary : {salaryContext.income}
            <TempSalary/>
        </div>
    )
}
function TempSalary() {
    const salaryContext=useContext(appContext)
    return (
        <div>
            Salary : {salaryContext.income}
        </div>
    )
}
export default ContextApp