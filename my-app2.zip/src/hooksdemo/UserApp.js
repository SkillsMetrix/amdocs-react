import { useEffect, useState } from 'react'

function UserApp() {
    const [users, setUsers] = useState([])

const handleChange=(e)=>{
     setUsers({...users,[e.target.name]:e.target.value})
}
const addUser = (e) => {
        e.preventDefault()
        console.log(users);
       
    }
    const deleteUser = (user) => {
        setUsers(users.filter((us) => us.uname !== user))
    }
    return (
       
            <form onSubmit={addUser}>
                <input placeholder='Enter Username' type='text' name='uname' onChange={handleChange} />
                <input placeholder='Enter Email' type='email' name='email' onChange={handleChange} />
           
                <button className='btn btn-success'>Add User</button>
            </form>
         
    )

}
export default UserApp