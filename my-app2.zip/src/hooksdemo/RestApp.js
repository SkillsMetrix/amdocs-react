import { Component } from 'react'
import axios from 'axios'
import RestData from './RestData'
const URL = 'https://jsonplaceholder.typicode.com/users'
export default class RestApp extends Component {

    state = {
        userData: []
    }

    componentDidMount() {
        axios.get(URL)
            .then((res) => res.data)
            .then((data) => {
                this.setState({ userData: data })


            })
    }
    render() {
        return (
            <div>
                <RestData rdata={this.state.userData} />
            </div>
        )
    }
}