import { useContext } from "react"
import { MyContext } from "./MyContext"


function MyComponent (){
    const myContext= useContext(MyContext)

    return(
        <div>
            My Comp Data :{myContext.map((data)=>(
                <div key={data}>{data.name}-- {data.email}</div>
            ))}
        </div>
    )
}
export default MyComponent