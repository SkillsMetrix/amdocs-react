import MyComponent from "./MyComponent"



function MainComp(){
    
    return(
        <div>
            <MyComponent/>
        </div>
    )
}
export default MainComp