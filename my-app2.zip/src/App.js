import logo from './logo.svg';
import './App.css';
import MainComp from './context/MainComp';
import { useState } from 'react';
import { MyContext } from './context/MyContext';
import ContextApp from './hooksdemo/ContextApiDemo';
import UserApp from './hooksdemo/UserApp';
 
const userData=[{name:'admin',email:'admin@mail.com'}]
function App() {
  const [user,setUser]=useState(userData)
  return (
    <div className="App">
      <MyContext.Provider value={user}>
      <MainComp/>
      </MyContext.Provider>
    <hr/>
    <UserApp/>
    </div>
  );
}

export default App;
